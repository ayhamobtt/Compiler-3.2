/*
************************************************************
* COMPILERS COURSE - Algonquin College
* Code version: Fall, 2022
* Author: Svillen Ranev - Paulo Sousa
* Professors: Paulo Sousa
************************************************************
 _________________________________
|                                 |
| ........ phx LANGUAGE ......... |
|     __    __    __    __        |
|    /  \  /  \  /  \  /  \       |
| __/  __\/  __\/  __\/  __\__    |
| _/  /__/  /__/  /__/  /_____|   |
|  \_/ \   / \   / \   / \  \___  |
|       \_/   \_/   \_/   \___o_> |
|                                 |
| .. ALGONQUIN COLLEGE - 2022F .. |
|_________________________________|

*/

/*
************************************************************
* File name: parser.h
* Compiler: MS Visual Studio 2022
* Course: CST 8152 � Compilers, Lab Section: [011, 012, 013]
* Assignment: A32.
* Date: Sep 01 2022
* Professor: Paulo Sousa
* Purpose: This file is the main header for Parser (.h)
*************************************************************/

#ifndef PARSER_H_
#define PARSER_H_

/* Inclusion section */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#ifndef COMPILERS_H_
#include "Compilers.h"
#endif
#ifndef READER_H_
#include "Reader.h"
#endif
#ifndef SCANNER_H_
#include "Scanner.h"
#endif

/* Global vars */
static Token lookahead;
extern BufferReader* stringLiteralTable;
extern phx_intg line;
extern Token tokenizer();
extern phx_char* keywordTable[];
phx_intg syntaxErrorNumber = 0;

#define STR_LANGNAME	"phx"
#define LANG_WRTE		"print&"
#define LANG_READ		"input&"
#define LANG_MAIN		"main&"

/* TO_DO: Create ALL constants for keywords (sequence given in table.h) */

/* Constants */
enum KEYWORDS {
	NO_ATTR = -1,
	KW_MAIN,
	KW_DATA,
	KW_CODE,
	KW_INT,
	KW_REAL,
	KW_STRING,
	KW_IF,
	KW_THEN,
	KW_ELSE,
	KW_WHILE,
	KW_DO,
	KW_OR,
	KW_PLUS,
	KW_MINUS,
	KW_MULT,
	KW_DIV,
	KW_AND
};

/* Function definitions */
phx_void startParser();
phx_void matchToken(phx_intg, phx_intg);
phx_void syncErrorHandler(phx_intg);
phx_void printError();

/* TO_DO: Place ALL non-terminal function declarations */
phx_void codeSession();
phx_void dataSession();
phx_void optVarListDeclarations();
phx_void optionalStatements();
phx_void outputStatement();
phx_void outputVariableList();
phx_void program();
phx_void statement();
phx_void statements();
phx_void variableList();
phx_void variableIdentifier();
phx_void statementsPrime();  
phx_void assignmentStatement();
phx_void assignmentExpression();
phx_void selectionStatememnt();
phx_void iterationStatement();
phx_void inputStatement();
phx_void outputList();
phx_void additiveArithmaticExpression();
phx_void unaryArithmaticExpression();
phx_void additiveArithmaticExpressionPrime(); 
phx_void multiplicativeArithmaticExpression();
phx_void multiplicativeArithmaticExpressionPrime();
phx_void stringExpression();
phx_void stringExpressionPrime(); 
phx_void primaryStringExpression();
phx_void conditionalExpression();
phx_void logicalOrExpression();
phx_void logicalOrExpressionPrime();
phx_void logicalAndExpression();
phx_void logicalAndExpressionPrime();
phx_void logicalNotExpression();
phx_void relationalExpression();
phx_void relationalAExpression();
phx_void relationalAExpressionPrime();
phx_void primaryARelationalExpression();
phx_void relationalSExpression();
phx_void relationalSExpressionPrime();
phx_void primarySRelationalExpression();

#endif
