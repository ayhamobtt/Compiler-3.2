/*
************************************************************
* COMPILERS COURSE - Algonquin College
* Code version: Summer, 2022
* Author: Svillen Ranev - Paulo Sousa
* Professors: Paulo Sousa
************************************************************
*/

/*
************************************************************
* File name: scanner.h
* Compiler: MS Visual Studio 2022
* Author: Paulo Sousa
* Course: CST 8152 � Compilers, Lab Section: [011, 012, 013]
* Assignment: A22, A32.
* Date: Jul 01 2022
* Professor: Paulo Sousa
* Purpose: This file contains all functionalities from Scanner.
* Function list: (...).
************************************************************
*/

/* TO_DO: Adjust the function header */

 /* The #define _CRT_SECURE_NO_WARNINGS should be used in MS Visual Studio projects
  * to suppress the warnings about using "unsafe" functions like fopen()
  * and standard sting library functions defined in string.h.
  * The define does not have any effect in Borland compiler projects.
  */
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>   /* standard input / output */
#include <ctype.h>   /* conversion functions */
#include <stdlib.h>  /* standard library functions and constants */
#include <string.h>  /* string functions */
#include <limits.h>  /* integer types constants */
#include <float.h>   /* floating-point types constants */

/* #define NDEBUG        to suppress assert() call */
#include <assert.h>  /* assert() prototype */

/* project header files */

#ifndef COMPILERS_H_
#include "Compilers.h"
#endif

#ifndef BUFFER_H_
#include "Reader.h"
#endif

#ifndef SCANNER_H_
#include "Scanner.h"
#endif

/*
----------------------------------------------------------------
TO_DO: Global vars definitions
----------------------------------------------------------------
*/

/* Global objects - variables */
/* This buffer is used as a repository for string literals. */
extern ReaderPointer stringLiteralTable;	/* String literal table */
phx_intg line;								/* Current line number of the source code */
extern phx_intg errorNumber;				/* Defined in platy_st.c - run-time error number */

extern phx_intg stateType[];
extern phx_char* keywordTable[];
extern PTR_ACCFUN finalStateTable[];
extern phx_intg transitionTable[][TABLE_COLUMNS];

/* Local(file) global objects - variables */
static ReaderPointer lexemeBuffer;			/* Pointer to temporary lexeme buffer */
static ReaderPointer sourceBuffer;			/* Pointer to input source buffer */


static int nextChar(char c);            /* character class function */
static int nextSt(int, char);        /* state machine function */
static int Keyword(char kw_lexeme[]); /* keywords lookup function */

/*
 ************************************************************
 * Intitializes scanner
 *		This function initializes the scanner using defensive programming.
 ***********************************************************
 */
 /* TO_DO: Follow the standard and adjust datatypes */

phx_intg startScanner(ReaderPointer psc_buf) {
	if (readerIsEmpty(psc_buf))
		return EXIT_FAILURE; /*1*/	/* in case the buffer has been read previously  */
	readerRecover(psc_buf);
	readerClear(stringLiteralTable);
	line = 1;
	sourceBuffer = psc_buf;
	return EXIT_SUCCESS; /*0*/
}

/*
 ************************************************************
 * Process Token
 *		Main function of buffer, responsible to classify a char (or sequence
 *		of chars). In the first part, a specific sequence is detected (reading
 *		from buffer). In the second part, a pattern (defined by Regular Expression)
 *		is recognized and the appropriate function is called (related to final states 
 *		in the Transition Diagram).
 ***********************************************************
 */

Token tokenizer(void) {

	/* TO_DO: Follow the standard and adjust datatypes */

	Token currentToken = { 0 }; /* token to return after pattern recognition. Set all structure members to 0 */
	phx _char c;	/* input symbol */
	phx_intg state = 0;		/* initial state of the FSM */
	phx_intg lexStart;		/* start offset of a lexeme in the input char buffer (array) */
	phx_intg lexEnd;		/* end offset of a lexeme in the input char buffer (array)*/

	phx_intg lexLength;		/* token length */
	phx_intg i;				/* counter */
	phx_char newc;			/* new char */
	
	while (1) { /* endless loop broken by token returns it will generate a warning */
		c = readerGetChar(sourceBuffer);

		/* ------------------------------------------------------------------------
			Part 1: Implementation of token driven scanner.
			Every token is possessed by its own dedicated code
			-----------------------------------------------------------------------
		*/

		if (isspace(c)) {
			if (c == '\n') {
				line++;
			}
			continue;
		}
		/* TO_DO: All patterns that do not require accepting functions */
		switch (c) {

		/* Cases for spaces */
		case ' ':
		case '\t':
		case '\f':
			break;
		case '\n':
			line++;
			break;

		/* Cases for symbols */
		case ';':
			currentToken.code = EOS_T;
			return currentToken;
		case '(':
			currentToken.code = LPR_T;
			return currentToken;
		case ')':
			currentToken.code = RPR_T;
			return currentToken;
		case '{':
			currentToken.code = LBR_T;
			return currentToken;
		case '}':
			currentToken.code = RBR_T;
			return currentToken;
		/* Comments */
		case '+': /*Checks for the addition operator*/
			newc = readerGetChar(sourceBuffer);
			if (newc == '+') { /*Checks for a second addition operator*/
				currentToken.code = ASD_OP_T;
				return currentToken;
			}
			else {/*retract so it stays a single +*/
				RTE(sourceBuffer);
				currentToken.code = ART_OP_T;
				currentToken.attribute.arithmeticOperator = PLUS;
				return currentToken; /*Return the left brace token*/
			}
		case '-': /*Checks for minus operator*/
			currentToken.code = phx_OP_T;
			currentToken.attribute.arithmeticOperator = MINUES;
			return currentToken;
		case '*': /*Checks for the multiplication operator*/
			currentToken.code = phx_OP_T;
			currentToken.attribute.arithmeticOperator = MULTIPLAY;
			return currentToken;
		case '/': /*Checks for the devision operator*/
			currentToken.code = phx_OP_T;
			currentToken.attribute.arithmeticOperator = DIVIDE;
			return currentToken;
		case '<': /*Checks for the smaller than operator*/
			currentToken.code = REL_OP_T;
			currentToken.attribute.relationalOperator = LT;
			return currentToken;
		case '>': /*Checks for the greater than operator*/
			currentToken.code = REL_OP_T;
			currentToken.attribute.relationalOperator = GT;
			return currentToken;
		case '!': /*Checks for the exclamation point character*/
			newc = bGetCh(sourceBuffer);
			if (newc == '=') { /*Checks for equal character afterwards*/
				currentToken.code = REL_OP_T;
				currentToken.attribute.relationalOperator = NE;
				return currentToken;
			}
		case '#':
			newc = readerGetChar(sourceBuffer);
			do {
				c = readerGetChar(sourceBuffer);
				if (c == CHARSEOF0 || c == CHARSEOF255) {
					readerRetract(sourceBuffer);
					//return currentToken;
				}
				else if (c == '\n') {
					line++;
				}
			} while (c != '#' && c != CHARSEOF0 && c != CHARSEOF255);
			break;
		/* Cases for END OF FILE */
		case CHARSEOF0:
			currentToken.code = SEOF_T;
			currentToken.attribute.seofType = SEOF_0;
			return currentToken;
		case CHARSEOF255:
			currentToken.code = SEOF_T;
			currentToken.attribute.seofType = SEOF_255;
			return currentToken;

		/* ------------------------------------------------------------------------
			Part 2: Implementation of Finite State Machine (DFA) or Transition Table driven Scanner
			Note: Part 2 must follow Part 1 to catch the illegal symbols
			-----------------------------------------------------------------------
		*/

		/* TO_DO: Adjust / check the logic for your language */

		default: // general case
			state = nextState(state, c);
			lexStart = readerGetPosRead(sourceBuffer) - 1;
			readerSetMark(sourceBuffer, lexStart);
			int pos = 0;
			while (stateType[state] == NOFS) {
				c = readerGetChar(sourceBuffer);
				state = nextState(state, c);
				pos++;
			}
			if (stateType[state] == FSWR)
				readerRetract(sourceBuffer);
			lexEnd = readerGetPosRead(sourceBuffer);
			lexLength = lexEnd - lexStart;
			lexemeBuffer = readerCreate((phx_int)lexLength + 2, 0, MODE_FIXED);
			if (!lexemeBuffer) {
				fprintf(stderr, "Scanner error: Can not create buffer\n");
				exit(1);
			}
			readerRestore(sourceBuffer);
			for (i = 0; i < lexLength; i++)
				readerAddChar(lexemeBuffer, readerGetChar(sourceBuffer));
			readerAddChar(lexemeBuffer, READER_TERMINATOR);
			currentToken = (*finalStateTable[state])(readerGetContent(lexemeBuffer, 0));
			readerRestore(lexemeBuffer); //xxx
			return currentToken;
		} // switch

	} //while

} // tokenizer


/*
 ************************************************************
 * Get Next State
	The assert(int test) macro can be used to add run-time diagnostic to programs
	and to "defend" from producing unexpected results.
	- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	(*) assert() is a macro that expands to an if statement;
	if test evaluates to false (zero) , assert aborts the program
	(by calling abort()) and sends the following message on stderr:
	(*) Assertion failed: test, file filename, line linenum.
	The filename and linenum listed in the message are the source file name
	and line number where the assert macro appears.
	- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	If you place the #define NDEBUG directive ("no debugging")
	in the source code before the #include <assert.h> directive,
	the effect is to comment out the assert statement.
	- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	The other way to include diagnostics in a program is to use
	conditional preprocessing as shown bellow. It allows the programmer
	to send more details describing the run-time problem.
	Once the program is tested thoroughly #define DEBUG is commented out
	or #undef DEBUG is used - see the top of the file.
 ***********************************************************
 */
/*
 ************************************************************
 * Get Next Token Class
	* Create a function to return the column number in the transition table:
	* Considering an input char c, you can identify the "class".
	* For instance, a letter should return the column for letters, etc.
 ***********************************************************
 */
/* TO_DO: Use your column configuration */

/* Adjust the logic to return next column in TT */
/*	[A-z](0), [0-9](1),	_(2), &(3), "(4), SEOF(5), other(6) */

phx_intg nextChar(phx_char c) {
	phx_intg val = -1;
	switch (c) {
	case CHRCOL2:
		val = 2;
		break;
	case CHRCOL3:
		val = 3;
		break;
	case CHRCOL4:
		val = 4;
		break;
	case CHARSEOF0:
	case CHARSEOF255:
		val = 5;
		break;
	default:
		if (isalpha(c))
			val = 0;
		else if (isdigit(c))
			val = 1;
		else
			val = 6;
	}
	return val;
}


 /*
  ************************************************************
  * Acceptance State Function IL
  *		Function responsible to identify IL (integer literals).
  * - It is necessary respect the limit (ex: 2-byte integer in C).
  * - In the case of larger lexemes, error shoul be returned.
  * - Only first ERR_LEN characters are accepted and eventually,
  *   additional three dots (...) should be put in the output.
  ***********************************************************
  */
  /* TO_DO: Adjust the function for IL */

Token funcIL(phx_char lexeme[]) {
	Token currentToken = { 0 };
	phx_long tlong;
	if (lexeme[0] != '\0' && strlen(lexeme) > NUM_LEN) {
		currentToken = (*finalStateTable[ESNR])(lexeme);
	}
	else {
		tlong = atol(lexeme);
		if (tlong >= 0 && tlong <= SHRT_MAX) {
			currentToken.code = INL_T;
			currentToken.attribute.intValue = (phx_intg)tlong;
		}
		else {
			currentToken = (*finalStateTable[ESNR])(lexeme);
		}
	}
	return currentToken;
}


/*
 ************************************************************
 * Acceptance State Function ID
 *		In this function, the pattern for IDs must be recognized.
 *		Since keywords obey the same pattern, is required to test if
 *		the current lexeme matches with KW from language.
 *	- Remember to respect the limit defined for lexemes (VID_LEN) and
 *	  set the lexeme to the corresponding attribute (vidLexeme).
 *    Remember to end each token with the \0.
 *  - Suggestion: Use "strncpy" function.
 ***********************************************************
 */
 /* TO_DO: Adjust the function for ID */

Token funcID(phx_char lexeme[]) {
	Token currentToken = { 0 };
	size_t length = strlen(lexeme);
	phx_char lastch = lexeme[length - 1];
	phx_intg isID = phx_FALSE;
	switch (lastch) {
		case MNIDPREFIX:
			currentToken.code = MNID_T;
			isID = phx_TRUE;
			break;
		default:
			// Test Keyword
			currentToken = funcKEY(lexeme);
			break;
	}
	if (isID == phx_TRUE) {
		strncpy(currentToken.attribute.idLexeme, lexeme, VID_LEN);
		currentToken.attribute.idLexeme[VID_LEN] = CHARSEOF0;
	}
	return currentToken;
}

/*

/*
 ************************************************************
 * The function prints the token returned by the scanner
 ***********************************************************
 */

phx_void printToken(Token t) {
	extern phx_char* keywordTable[]; /* link to keyword table in */
	switch (t.code) {
	case RTE_T:
		printf("RTE_T\t\t%s", t.attribute.errLexeme);
		/* Call here run-time error handling component */
		if (errorNumber) {
			printf("%d", errorNumber);
			exit(errorNumber);
		}
		printf("\n");
		break;
	case ERR_T:
		printf("ERR_T\t\t%s\n", t.attribute.errLexeme);
		break;
	case SEOF_T:
		printf("SEOF_T\t\t%d\t\n", t.attribute.seofType);
		break;
	case AVID_T:
		printf("MNID_T\t\t%s\n", t.attribute.idLexeme);
		break;
	case LBR_T:
		printf("LBR_T\n");
		break;
	case SVID_T:
		printf("VAR_T\t\t%s\n", t.attribute.idLexeme);
		break;
	case STR_T:
		printf("STR_T\t\t%d\t ", (viper_intg)t.attribute.codeType);
		printf("%s\n", readerGetContent(stringLiteralTable, (viper_intg)t.attribute.codeType));
		break;
	case LPR_T:
		printf("LPR_T\n");
		break;
	case RPR_T:
		printf("RPR_T\n");
		break;
	case INL_T:
		printf("INL_T\t\t%d\n", t.attribute.intValue);
		break;
	case ASD_OP_T:
		printf("ARI_T\t\t%d\n", t.attribute.arithmeticOperator);
		break;
	case RBR_T:
		printf("RBR_T\n");
		break;
	case KW_T:
		printf("KW_T\t\t%s\n", keywordTable[t.attribute.codeType]);
		break;
	case EOS_T:
		printf("EOS_T\n");
		break;
	case phx_OP_T:
		printf("CLN_T\n");
		break;
	case ASD_OP_T:
		printf("EQS_T\n");
		break;
	case REL_OP_T:
		printf("REL_T\n");
		break;
	case ASS_OP_T:
		printf("LOG_T\n");
		break;
	default:
		printf("Scanner error: invalid token code: %d\n", t.code);
	}




}
int nextClass(char c) {
	phx_int int val = -1;
	/*				[A-z](0),	[0-9](1),	.(2),	$(3),	'(4),	SEOF(5),	other(6) */
	if (isalpha(c)) {
		val = 0;
	}
	else if (isdigit(c)) {
		val = 1;
	}
	else if (c == '.') {
		val = 2;
	}
	else if (c == '$') {
		val = 3;
	}
	else if (c == '\'') {
		val = 4;
	}
	else if (c == CHARSEOF0 || c == CHARSEOF255) {
		val = 5;
	}
	else {
		val = 6;
	}
	return val;
}
Token funcFUNC(char lexeme[]) {
	Token currentToken = { 0 };
	int i;
	if (Keyword(lexeme) != RT_FAIL_1) {
		currentToken.code = KW_T;
		currentToken.attribute.keywordIndex = Keyword(lexeme);
		return currentToken;
	}
	else {
		currentToken.code = AVID_T;
	}
	if (strlen(lexeme) > VID_LEN) {
		for (i = 0; i < VID_LEN; i++) {
			currentToken.attribute.vidLexeme[i] = lexeme[i];
		}
		currentToken.attribute.vidLexeme[VID_LEN] = CHARSEOF0;
	}
	else {
		strcpy(currentToken.attribute.vidLexeme, lexeme);
		currentToken.attribute.vidLexeme[strlen(lexeme)] = CHARSEOF0;
	}
	return currentToken;
}
/*
************************************************************
 * Acceptance State Function SL
 *		Function responsible to identify SL (string literals).
 * - The lexeme must be stored in the String Literal Table
 *   (stringLiteralTable). You need to include the literals in
 *   this structure, using offsets. Remember to include \0 to
 *   separate the lexemes. Remember also to incremente the line.
 ***********************************************************
 */
Token funcQR(char lexeme[]) {
	Token currentToken = { 0 };
	int i;
	currentToken.code = SVID_T;
	if (strlen(lexeme) > VID_LEN) {
		for (i = 0; i < VID_LEN; i++) {
			currentToken.attribute.vidLexeme[i] = lexeme[i];
		}
		currentToken.attribute.vidLexeme[VID_LEN - 1] = '$';
		currentToken.attribute.vidLexeme[VID_LEN] = CHARSEOF0;
	}
	else {
		strcpy(currentToken.attribute.vidLexeme, lexeme);
		currentToken.attribute.vidLexeme[strlen(lexeme)] = CHARSEOF0;
	}

	return currentToken;
}
Token funcIL(char lexeme[]) {
	Token currentToken = { 0 };
	int sToInt = folt(lexeme); /* convert to int*/
	if (sToInt < SHRT_MIN || sToInt > SHRT_MAX) {
		currentToken = funcErr(lexeme);
	}
	else {

		currentToken.code = INL_T;
		currentToken.attribute.intValue = sToInt;
	}
	return currentToken;
}
/*
 ************************************************************
 * Get Next State
	The assert(int test) macro can be used to add run-time diagnostic to programs
	and to "defend" from producing unexpected results.
	- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	(*) assert() is a macro that expands to an if statement;
	if test evaluates to false (zero) , assert aborts the program
	(by calling abort()) and sends the following message on stderr:
	(*) Assertion failed: test, file filename, line linenum.
	The filename and linenum listed in the message are the source file name
	and line number where the assert macro appears.
	- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	If you place the #define NDEBUG directive ("no debugging")
	in the source code before the #include <assert.h> directive,
	the effect is to comment out the assert statement.
	- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	The other way to include diagnostics in a program is to use
	conditional preprocessing as shown bellow. It allows the programmer
	to send more details describing the run-time problem.
	Once the program is tested thoroughly #define DEBUG is commented out
	or #undef DEBUG is used - see the top of the file.
 ***********************************************************
 */
Token funcEX(char lexeme[]) {
	int i;
	Token currentToken = { 0 };
	currentToken.code = STR_T;
	/*Where first char will be added*/
	currentToken.attribute.contentString = readerGetPosRead(stringLiteralTable);
	/*Copy lexeme to String Literal Table*/
	for (i = 0; i < (signed)strlen(lexeme); i++) {
		/*Ignore the opening and closing quotes*/
		if (!(lexeme[i] == '\'')) {
			readerAddChar(stringLiteralTable, lexeme[i]);
		}
		if (lexeme[i] == '\n') {
			line++;
		}
	}
	/*  \0 to separate the lexemes*/
	readerAddChar(stringLiteralTable, '\0');
	return currentToken;
}
/*
************************************************************
*Acceptance State Function Error
* Function responsible to deal with ERR token.
* -This function uses the errLexeme, respecting the limit given
* by ERR_LEN.If necessary, use three dots(...) to use the
* limit defined.The error lexeme contains line terminators,
* so remember to increment line.
**********************************************************/
Token funcErr(char lexeme[]) {
	Token currentToken = { 0 };
	int i;
	/*if the lexeme is long than the defined limit, remove last 3 chars*/
	/*and append ... to indicate there is more*/

	if (strlen(lexeme) > ERR_LEN) {
		for (i = 0; i < (ERR_LEN - 3); i++) {
			if (lexeme[i] == '\n') {
				line++;
			}
			currentToken.attribute.errLexeme[i] = lexeme[i];
		}
		/*appending ...*/
		strcat(currentToken.attribute.errLexeme, "...");
	}
	else {
		for (i = 0; i < (signed)strlen(lexeme); i++) {
			if (lexeme[i] == '\n') {
				line++;
			}
			currentToken.attribute.errLexeme[i] = lexeme[i];
		}
	}

	currentToken.code = ERR_T;


	return currentToken;
}

/*
************************************************************
 * This function checks if one specific lexeme is a keyword.
 * - Tip: Remember to use the keywordTable to check the keywords.
 ***********************************************************
 */

int Keyword(char lexeme[]) {
	int i;
	if (!strlen(lexeme)) {
		return RT_FAIL_1;

	}
	for (i = 0; i < KWT_SIZE; i++) {
		if (strcmp(lexeme, keywordTable[i]) == 0) {
			return i;
		}
	}
	return RT_FAIL_1;
}
/*
TO_DO: (If necessary): HERE YOU WRITE YOUR ADDITIONAL FUNCTIONS (IF ANY).
*/
