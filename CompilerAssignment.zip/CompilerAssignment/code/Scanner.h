/*
************************************************************
* COMPILERS COURSE - Algonquin College
* Code version: Winter, 2022
* Author: Svillen Ranev - Paulo Sousa
* Professors: Paulo Sousa
************************************************************
*/

/*
************************************************************
* File name: scanner.h
* Compiler: MS Visual Studio 2022
* Author: Paulo Sousa
* Course: CST 8152 � Compilers, Lab Section: [011, 012, 013]
* Assignment: A22, A32.
* Date: Jul 01 2022
* Purpose: This file is the main header for Scanner (.h)
* Function list: (...).
*************************************************************/

#ifndef COMPILERS_H_
#include "Compilers.h"
#endif

#ifndef SCANNER_H_
#define SCANNER_H_

#ifndef NULL
#include <_null.h> /* NULL pointer constant is defined there */
#endif

/*#pragma warning(1:4001) */	/*to enforce C89 type comments  - to make //comments an warning */

/*#pragma warning(error:4001)*/	/* to enforce C89 comments - to make // comments an error */

/* Constants */
#define VID_LEN 20  /* variable identifier length */
#define ERR_LEN 40  /* error message length */
#define NUM_LEN 5   /* maximum number of digits for IL */

#define RTE_CODE 1  /* Value for run-time error */

/* TO_DO: Define Token codes - Create your token classes */
enum TOKENS {
#define ERR_T     0  /* Error token */
#define SEOF_T    1  /* Source end-of-file token */
#define AVID_T    2  /* Arithmetic Variable identifier token */
#define SVID_T    3  /* String Variable identifier token */
#define FPL_T     4  /* Floating point literal token */
#define INL_T     5  /* Integer literal token */
#define STR_T     6  /* String literal token */
#define ASD_OP_T  7  /* String concatenation operator token */
#define ASS_OP_T  8  /* Assignment operator token */
#define phx_OP_T  9  /* Arithmetic operator token */
#define REL_OP_T 10  /* Relational operator token */ 
#define LOG_OP_T 11  /* Logical operator token */
#define LPR_T    12  /* Left parenthesis token */
#define RPR_T    13  /* Right parenthesis token */
#define LBR_T    14  /* Left brace token */
#define RBR_T    15  /* Right brace token */
#define KW_T     16  /* Keyword token */
#define COM_T    17  /* Comma token */
#define EOS_T    18  /* End of statement *(semi - colon) */
};

/* TO_DO: Operators token attributes */
typedef enum ArithmeticOperators { PLUS, MINUES, MULTIPLAY, DIVIDE } AriOperator;
typedef enum RelationalOperators { EQ, NE, GT, LT } RelOperator;
typedef enum LogicalOperators { AND, OR, NOT } LogOperator;
typedef enum SourceEndOfFile { SEOF_0, SEOF_255 } EofOperator;

/* TO_DO: Data structures for declaring the token and its attributes */
typedef union TokenAttribute {
	phx_intg codeType;      /* integer attributes accessor */
	AriOperator arithmeticOperator;		/* arithmetic operator attribute code */
	RelOperator relationalOperator;		/* relational operator attribute code */
	LogOperator logicalOperator;		/* logical operator attribute code */
	EofOperator seofType;				/* source-end-of-file attribute code */
	phx_intg intValue;						/* integer literal attribute (value) */
	phx_intg keywordIndex;					/* keyword index in the keyword table */
	phx_intg contentString;				/* string literal offset from the beginning of the string literal buffer (stringLiteralTable->content) */
	phx_real floatValue;					/* floating-point literal attribute (value) */
	phx_char idLexeme[VID_LEN + 1];		/* variable identifier token attribute */
	phx_char errLexeme[ERR_LEN + 1];		/* error token attribite */
} TokenAttribute;

/* TO_DO: Should be used if no symbol table is implemented */
typedef struct idAttibutes {
	phx_byte flags;			/* Flags information */
	union {
		phx_intg intValue;				/* Integer value */
		phx_real floatValue;			/* Float value */
		phx_char* stringContent;		/* String value */
		
	} values;
} IdAttibutes;

/* Token declaration */
typedef struct Token {
	phx_intg code;				/* token code */
	TokenAttribute attribute;	/* token attribute */
	IdAttibutes   idAttribute;	/* not used in this scanner implementation - for further use */
} Token;

///////////////////////////////////////////////////////////////////////////////////////////////////////

/* EOF definitions */
#define CHARSEOF0 '\0'
#define CHARSEOF255 0xFF

/*  Special case tokens processed separately one by one in the token-driven part of the scanner
 *  '=' , ' ' , '(' , ')' , '{' , '}' , == , <> , '>' , '<' , ';', 
 *  white space, #comment\n , ',' , ';' , '-' , '+' , '*' , '/', # , 
 *  .&., .|. , .!. , SEOF.
 */

/* TO_DO: Define lexeme FIXED classes */
/* These constants will be used on nextClass */
#define CHRCOL2 '_'
#define CHRCOL3 '&'
#define CHRCOL4 '\''
#define CHRCOL4 '"''


/* These constants will be used on VID / MID function */
#define MNIDPREFIX '&'

/* TO_DO: Error states and illegal state */
#define FS		-1		/* Illegal state */
#define ESWR	12		/* Error state with retract */
#define ESNR	11		/* Error state with no retract */

 /* TO_DO: State transition table definition */
#define TABLE_COLUMNS 7

/* TO_DO: Transition table - type of states defined in separate table */
static phx_intg transitionTable[][TABLE_COLUMNS] = {
/*   [A-z] , [0-9],    _,    &,    ", SEOF, other
	   L(0),  D(1), U(2), M(3), Q(4), E(5),  O(6) */
	{     1,  ESNR, ESNR, ESNR,    4, ESWR, ESNR}, // S0: NOAS
	{     1,     1,    1,    2, ESNR, ESWR,    3}, // S1: NOAS
	{    FS,    FS,   FS,   FS,   FS,   FS,   FS}, // S2: ASNR (MVID)
	{    FS,    FS,   FS,   FS,   FS,   FS,   FS}, // S3: ASWR (KEY)
	{     4,     4,    4,    4,    5, ESWR,    4}, // S4: NOAS
	{	FS,		FS,		FS,	FS,		FS,	 FS, FS }, // S5:
	{	ESWR,		ESNR,	 9,	 ESNR,	 7,	 ESWR,	 5 }, // S6:
	{	 8,		7,		 7,		 7,		 8,		 8,	 8 }, // S7:
	{	FS,	 FS,	 FS,	 FS,	 FS,	 FS, FS }, // S8:
	{	 ESNR,	 9,	 9,	 ESWR,	 ESNR,	 ESNR,	 10 }, // S9:
	{    FS,    FS,   FS,   FS,   FS,   FS,   FS}, // S10: ASNR (SL)
	{    FS,    FS,   FS,   FS,   FS,   FS,   FS}, // S11: ASNR (ES)
	{    FS,    FS,   FS,   FS,   FS,   FS,   FS}  // s12: ASWR (ER)
};

/* Define accepting states types */
#define NOFS	0		/* not accepting state */
#define FSNR	1		/* accepting state with no retract */
#define FSWR	2		/* accepting state with retract */

/* TO_DO: Define list of acceptable states */
static phx_int stateType[] = {
	NOFS, /* 00 */
	NOFS, /* 01 */
	FSNR, /* 02 (MID) - Methods */
	FSWR, /* 03 (KEY) */
	NOFS, /* 04 */
	FSNR, /* 05 (SL) */
	FSNR, /* 06 (Err1 - no retract) */
	FSWR,  /* 07 (Err2 - retract) */
	NOFS,
	FSWR,
	FSNR,
	FSNR
};

/*
-------------------------------------------------
TO_DO: Adjust your functions'definitions
-------------------------------------------------
*/

/* Static (local) function  prototypes */
phx_intg startScanner(ReaderPointer psc_buf);
static phx_intg nextClass(phx_char c);			/* character class function */
static phx_intg nextState(phx_intg, phx_char);		/* state machine function */

/*
-------------------------------------------------
Automata definitions
-------------------------------------------------
*/

/* TO_DO: Pointer to function (of one char * argument) returning Token */
typedef Token(*PTR_ACCFUN)(phx_char* lexeme);

/* Declare accepting states functions */
Token funcEX	(phx_char lexeme[]);
Token funcID	(phx_char lexeme[]);
Token funcKEY	(phx_char lexeme[]);
Token funcErr	(phx_char lexeme[]);
Token funcQR	(phx_char lexeme[]);
Token funcFUNC	(phx_char lexeme[]);
Token funcIL	(phx_char lexeme[]);



/* 
 * Accepting function (action) callback table (array) definition 
 * If you do not want to use the typedef, the equvalent declaration is:
 */

/* TO_DO: Define final state table */
static PTR_ACCFUN finalStateTable[] = {
	NULL,		/* -    [00] */
	NULL,		/* -    [01] */
	funcID,		/* MNID	[02] */
	funcKEY,	/* KEY  [03] */
	NULL,		/* -    [04] */
	funcKEY,	/* KEY  [05] */
	NULL,		/* -    [06] */
	NULL,		/* -    [07] */
	funcSL,		/* SL   [08] */
	funcErr,	/* ERR1 [09] */
	funcErr		/* ERR2 [010] */
};

/*
-------------------------------------------------
Language keywords
-------------------------------------------------
*/

/* TO_DO: Define the number of Keywords from the language */
#define KWT_SIZE 10

/* TO_DO: Define the list of keywords */
static phx_char* keywordTable[KWT_SIZE] = {
	"data",
	"code",
	"int",
	"real",
	"string",
	"if",
	"then",
	"else",
	"while",
	"do",
	"true",
	"false",
	"import",
	"retuen",
};

/* NEW SECTION: About indentation */

/*
 * Scanner attributes to be used (ex: including: intendation data
 */

#define INDENT '\t'  /* Tabulation */

/* TO_DO: Should be used if no symbol table is implemented */
typedef struct languageAttributes {
	phx_char indentationCharType;
	phx_intg indentationCurrentPos;
	/* TO_DO: Include any extra attribute to be used in your scanner (OPTIONAL and FREE) */
} LanguageAttributes;

#endif
